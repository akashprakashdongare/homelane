import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-mangement',
  templateUrl: './query-mangement.component.html',
  styleUrls: ['./query-mangement.component.css']
})
export class QueryMangementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
