import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-management',
  templateUrl: './vendor-management.component.html',
  styleUrls: ['./vendor-management.component.css']
})
export class VendorManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
