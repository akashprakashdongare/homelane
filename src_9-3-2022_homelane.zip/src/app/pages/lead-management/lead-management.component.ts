import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lead-management',
  templateUrl: './lead-management.component.html',
  styleUrls: ['./lead-management.component.css']
})
export class LeadManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
