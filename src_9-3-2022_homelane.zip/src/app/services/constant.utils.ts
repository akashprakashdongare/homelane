export class Constant{

    static  SUCCESS_STATUS: string= 'success';

    static  SUCCESS_MESSAGE: string= 'Your action has been successfully submitted !';

    static  ERROR_STATUS: string= 'error';

    static  ERROR_MESSAGE: string= 'Something went wrong.';

    static APPROVAL_STATUS: string= 'A';

    static REJECT_STATUS: string= 'R';

    static HOLD_STATUS: string= 'H';

    
     
}